package com.neueda.buildingaccessmanagementsimulator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BuildingAccessManagementSimulatorApplication {

    public static void main(String[] args) {
        SpringApplication.run(BuildingAccessManagementSimulatorApplication.class, args);
    }

}
